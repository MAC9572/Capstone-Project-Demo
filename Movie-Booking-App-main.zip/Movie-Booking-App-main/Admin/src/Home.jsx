import React from 'react'
import './App.css'

const Home = () => {
  return (
    <div className='bg'>
        <div >
            

            <div className='cont'>
                <h1>Welcome to TIX4U Admin Page</h1>
            </div>
        
            <button className='btn'>Let's Start</button>
        

        </div>
        
    </div>
  )
}

export default Home