import React from 'react'
import image from '../ADD/TIX4U.png'
const Add = () => {
  return (
    <div>
        <img className='add container ms-5 mb-5 mt-3' src={image} alt="add" />
    </div>
  )
}

export default Add